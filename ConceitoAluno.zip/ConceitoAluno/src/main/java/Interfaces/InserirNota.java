/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

import javax.swing.JOptionPane;

/**
 *
 * @author maria
 */
public class InserirNota implements Constantes{
    // adicionando variaveis
    public String a;
    public String b;
    public String c; 
    public int nota;
   // implementa��o do metodo da interface
    @Override
    public void inserirNota() {
        this.a=a;
        this.b=b;
        this.c=c;
        this.nota=nota;
        
        //Usando o metodo de showInputDialog() para solicitar nota para o usuario
        nota=Integer.parseInt(JOptionPane.showInputDialog(null,"Digite sua nota: "));
        nota=nota;
        //estrutura de decis�o
        if(nota==10){
            //exibindo resultado na tela atrav�s do JOptionPane.showMessageDialog
            JOptionPane.showMessageDialog(null,"Parab�ns, voc� atingiu todos os indicadores de avalia��o com excel�ncia");
        }else{
            if(nota>=7 && nota<10){
                JOptionPane.showMessageDialog(null,"Parab�ns, voc� obteve aproveitamento satisfat�rio nos indicadores de avalia��o");
        }else{
               JOptionPane.showMessageDialog(null,"Voc� n�o atingiu o m�nimo esperado para aprova��o");
        }
        }
               
    }
    
   
    
}
