/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Interfaces;

/**
 *
 * @author maria
 */
public class Imprimir {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //instanciando o metodo da classe InserirALuno
        InserirNota in = new InserirNota();
        in.inserirNota();
    }
    
}
