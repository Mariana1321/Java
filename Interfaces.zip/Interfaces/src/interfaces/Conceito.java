
package interfaces;

public interface Conceito {
    String a = "Parabéns você atingiu todos os indicadores de avaliação com excelência";
    String b = "Parabéns você obteve aproveitamento satisfatório nos indicadores de avaliação";
    String c = "Você não atingiu o mínimo esperado para aprovação"; 
    
}
